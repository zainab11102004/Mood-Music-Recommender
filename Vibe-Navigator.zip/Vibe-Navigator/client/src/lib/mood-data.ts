import { 
  CloudRain, 
  Sun, 
  Zap, 
  Coffee, 
  Moon, 
  Heart, 
  Music, 
  BookOpen,
  Dumbbell,
  Gamepad2,
  Headphones,
  Utensils
} from "lucide-react";

export type MoodType = {
  id: string;
  label: string;
  icon: any;
  color: string;
  description: string;
  backgroundGradient: string;
};

export type RecommendationType = {
  music: {
    genre: string;
    playlist: string;
    description: string;
  }[];
  activities: {
    title: string;
    icon: any;
    description: string;
    duration: string;
  }[];
};

export const moods: MoodType[] = [
  {
    id: "calm",
    label: "Calm",
    icon: CloudRain,
    color: "text-blue-300",
    description: "Feeling peaceful and introspective.",
    backgroundGradient: "from-blue-900/50 via-indigo-900/50 to-slate-900/50",
  },
  {
    id: "energetic",
    label: "Energetic",
    icon: Zap,
    color: "text-yellow-300",
    description: "Ready to move and take on the world.",
    backgroundGradient: "from-orange-900/50 via-amber-900/50 to-red-900/50",
  },
  {
    id: "happy",
    label: "Happy",
    icon: Sun,
    color: "text-orange-300",
    description: "Joyful and looking for good vibes.",
    backgroundGradient: "from-pink-900/50 via-rose-900/50 to-orange-900/50",
  },
  {
    id: "focused",
    label: "Focused",
    icon: Coffee,
    color: "text-emerald-300",
    description: "In the zone and productive.",
    backgroundGradient: "from-emerald-900/50 via-teal-900/50 to-cyan-900/50",
  },
  {
    id: "melancholy",
    label: "Melancholy",
    icon: Moon,
    color: "text-indigo-300",
    description: "A bit blue, needing comfort.",
    backgroundGradient: "from-indigo-950 via-slate-900 to-black",
  },
  {
    id: "romantic",
    label: "Romantic",
    icon: Heart,
    color: "text-pink-300",
    description: "Feeling loving and affectionate.",
    backgroundGradient: "from-pink-900/50 via-fuchsia-900/50 to-purple-900/50",
  },
];

export const recommendations: Record<string, RecommendationType> = {
  calm: {
    music: [
      { genre: "Lo-Fi Beats", playlist: "Chill Hop Essentials", description: "Soft, crackling beats to relax to." },
      { genre: "Ambient", playlist: "Deep Space", description: "Atmospheric soundscapes for drifting away." },
      { genre: "Acoustic Folk", playlist: "Cabin Vibes", description: "Gentle guitar melodies." },
    ],
    activities: [
      { title: "Read a Book", icon: BookOpen, description: "Get lost in a good story.", duration: "30+ min" },
      { title: "Meditation", icon: Moon, description: "Focus on your breathing.", duration: "10 min" },
      { title: "Sketching", icon: Utensils, description: "Draw whatever comes to mind.", duration: "20 min" },
    ],
  },
  energetic: {
    music: [
      { genre: "Synthwave", playlist: "Neon Nights", description: "Retro-futuristic driving beats." },
      { genre: "Pop Hits", playlist: "Top 50 Global", description: "Sing along to the latest bangers." },
      { genre: "Drum & Bass", playlist: "Liquid Gold", description: "Fast-paced rhythms to keep you moving." },
    ],
    activities: [
      { title: "Quick Workout", icon: Dumbbell, description: "HIIT session to burn energy.", duration: "20 min" },
      { title: "Clean the House", icon: Utensils, description: "Organize your space.", duration: "30 min" },
      { title: "Dance", icon: Music, description: "Just move to the rhythm.", duration: "15 min" },
    ],
  },
  happy: {
    music: [
      { genre: "Indie Pop", playlist: "Feel Good Indie", description: "Upbeat and sunny tunes." },
      { genre: "Disco", playlist: "Saturday Night Fever", description: "Groovy classics." },
      { genre: "Reggae", playlist: "Island Vibes", description: "Relaxed but cheerful rhythms." },
    ],
    activities: [
      { title: "Socialize", icon: Gamepad2, description: "Call a friend or meet up.", duration: "Variable" },
      { title: "Cook a Meal", icon: Utensils, description: "Try a new colorful recipe.", duration: "45 min" },
      { title: "Walk Outside", icon: Sun, description: "Soak up some vitamin D.", duration: "30 min" },
    ],
  },
  focused: {
    music: [
      { genre: "Classical", playlist: "Mozart for Study", description: "Complex harmonies to stimulate the brain." },
      { genre: "Binaural Beats", playlist: "Deep Focus", description: "Audio frequencies for concentration." },
      { genre: "Video Game OSTs", playlist: "RPG Soundtracks", description: "Designed to keep you engaged.", },
    ],
    activities: [
      { title: "Deep Work", icon: Coffee, description: "Tackle that big project.", duration: "90 min" },
      { title: "Journaling", icon: BookOpen, description: "Plan your week or reflect.", duration: "15 min" },
      { title: "Learn a Skill", icon: Gamepad2, description: "Practice coding or a language.", duration: "30 min" },
    ],
  },
  melancholy: {
    music: [
      { genre: "Post-Rock", playlist: "Cinematic Swells", description: "Emotional crescendos and textures." },
      { genre: "Sad Piano", playlist: "Rainy Day", description: "Melancholic keys.", },
      { genre: "Blues", playlist: "Midnight Blues", description: "Soulful expression of sorrow." },
    ],
    activities: [
      { title: "Journaling", icon: BookOpen, description: "Write down your feelings.", duration: "20 min" },
      { title: "Comfort Movie", icon: Gamepad2, description: "Watch a favorite film.", duration: "120 min" },
      { title: "Hot Bath", icon: Coffee, description: "Relax in warm water.", duration: "30 min" },
    ],
  },
  romantic: {
    music: [
      { genre: "R&B", playlist: "Smooth Jams", description: "Silky vocals and slow beats." },
      { genre: "Jazz", playlist: "Late Night Jazz", description: "Sophisticated and intimate." },
      { genre: "Ballads", playlist: "Love Songs", description: "Emotional powerhouses." },
    ],
    activities: [
      { title: "Stargazing", icon: Moon, description: "Look up at the night sky.", duration: "30 min" },
      { title: "Poetry", icon: BookOpen, description: "Read or write something beautiful.", duration: "20 min" },
      { title: "Slow Dance", icon: Music, description: "Even if it's just in the kitchen.", duration: "10 min" },
    ],
  },
};
