import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { moods, recommendations, type MoodType } from "@/lib/mood-data";
import { ArrowLeft, Music, Activity, Sparkles, PlayCircle, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import calmBg from "@assets/generated_images/soft_ethereal_blue_and_purple_gradient_clouds_for_calm_mood_background.png";
import happyBg from "@assets/generated_images/vibrant_energetic_orange_and_pink_gradient_for_happy_mood_background.png";

export default function Home() {
  const [selectedMood, setSelectedMood] = useState<MoodType | null>(null);

  const handleMoodSelect = (mood: MoodType) => {
    setSelectedMood(mood);
  };

  const handleBack = () => {
    setSelectedMood(null);
  };

  // Determine background based on mood
  const getBackgroundImage = () => {
    if (!selectedMood) return "";
    if (["calm", "melancholy", "focused", "romantic"].includes(selectedMood.id)) return calmBg;
    return happyBg;
  };

  return (
    <div className="min-h-screen w-full overflow-hidden bg-background text-foreground relative transition-colors duration-1000">
      {/* Animated Background Gradient Layer */}
      <div 
        className={`absolute inset-0 opacity-30 transition-opacity duration-1000 bg-gradient-to-br ${selectedMood ? selectedMood.backgroundGradient : "from-slate-900 via-purple-950 to-slate-900"}`} 
      />
      
      {/* Image Overlay for extra texture */}
      <AnimatePresence mode="wait">
        {selectedMood && (
          <motion.div 
            key={selectedMood.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.15 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-cover bg-center bg-no-repeat pointer-events-none mix-blend-overlay"
            style={{ backgroundImage: `url(${getBackgroundImage()})` }}
          />
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="relative z-10 container mx-auto px-4 py-8 min-h-screen flex flex-col">
        
        {/* Header */}
        <header className="flex items-center justify-between mb-12 pt-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-primary animate-pulse" />
            <h1 className="text-2xl font-serif font-bold tracking-tight">MoodMelody</h1>
          </div>
        </header>

        <AnimatePresence mode="wait">
          {!selectedMood ? (
            /* Mood Selection Screen */
            <motion.div
              key="selection"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="flex-1 flex flex-col justify-center items-center max-w-4xl mx-auto w-full"
            >
              <div className="text-center mb-12 space-y-4">
                <h2 className="text-5xl md:text-7xl font-serif font-medium text-white leading-tight">
                  How are you <br />
                  <span className="text-gradient">feeling today?</span>
                </h2>
                <p className="text-lg text-muted-foreground max-w-md mx-auto">
                  Select a mood to receive personalized music and activity recommendations tailored just for you.
                </p>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 w-full">
                {moods.map((mood, index) => (
                  <motion.button
                    key={mood.id}
                    onClick={() => handleMoodSelect(mood)}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.05 }}
                    whileHover={{ scale: 1.03, backgroundColor: "rgba(255,255,255,0.08)" }}
                    whileTap={{ scale: 0.98 }}
                    className="group relative flex flex-col items-center justify-center p-8 rounded-3xl border border-white/5 bg-white/5 backdrop-blur-sm hover:border-white/20 transition-all duration-300 aspect-square text-center gap-4"
                    data-testid={`mood-button-${mood.id}`}
                  >
                    <div className={`p-4 rounded-full bg-white/5 group-hover:bg-white/10 transition-colors duration-300 ${mood.color}`}>
                      <mood.icon size={32} strokeWidth={1.5} />
                    </div>
                    <div>
                      <h3 className="text-xl font-medium text-white mb-1">{mood.label}</h3>
                      <p className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity duration-300 absolute bottom-4 left-0 right-0 px-4">
                        {mood.description}
                      </p>
                    </div>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          ) : (
            /* Recommendation Screen */
            <motion.div
              key="recommendation"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              className="flex-1 max-w-5xl mx-auto w-full"
            >
              <div className="mb-8 flex items-center gap-4">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={handleBack}
                  className="rounded-full hover:bg-white/10"
                >
                  <ArrowLeft className="w-5 h-5" />
                </Button>
                <div>
                  <p className="text-sm text-muted-foreground">Current Mood</p>
                  <h2 className={`text-3xl font-serif ${selectedMood.color} flex items-center gap-2`}>
                    <selectedMood.icon className="w-6 h-6" />
                    {selectedMood.label}
                  </h2>
                </div>
              </div>

              <div className="grid lg:grid-cols-2 gap-8">
                {/* Music Column */}
                <div className="space-y-6">
                  <div className="flex items-center gap-2 text-xl font-medium text-white mb-4">
                    <Music className="w-5 h-5 text-primary" />
                    <h3>Soundtrack</h3>
                  </div>
                  
                  <div className="grid gap-4">
                    {recommendations[selectedMood.id].music.map((track, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.2 + i * 0.1 }}
                      >
                        <Card className="glass-panel border-white/10 bg-white/5 hover:bg-white/10 transition-colors">
                          <CardContent className="p-6 flex items-center gap-4">
                            <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center text-primary shrink-0">
                              <PlayCircle size={24} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between mb-1">
                                <h4 className="font-medium text-white truncate">{track.genre}</h4>
                                <span className="text-xs font-mono px-2 py-1 rounded-full bg-white/5 text-muted-foreground">Playlist</span>
                              </div>
                              <p className="text-sm text-white/80 font-medium">{track.playlist}</p>
                              <p className="text-xs text-muted-foreground mt-1">{track.description}</p>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Activities Column */}
                <div className="space-y-6">
                   <div className="flex items-center gap-2 text-xl font-medium text-white mb-4">
                    <Activity className="w-5 h-5 text-primary" />
                    <h3>Suggested Activities</h3>
                  </div>

                  <div className="grid gap-4">
                    {recommendations[selectedMood.id].activities.map((activity, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.3 + i * 0.1 }}
                      >
                        <Card className="glass-panel border-white/10 bg-white/5 hover:bg-white/10 transition-colors">
                          <CardContent className="p-6">
                            <div className="flex items-start justify-between mb-2">
                              <div className="flex items-center gap-3">
                                <div className={`p-2 rounded-lg bg-white/5 ${selectedMood.color}`}>
                                  <activity.icon size={18} />
                                </div>
                                <h4 className="font-medium text-white">{activity.title}</h4>
                              </div>
                              <div className="flex items-center gap-1 text-xs text-muted-foreground bg-white/5 px-2 py-1 rounded-md">
                                <Clock size={12} />
                                {activity.duration}
                              </div>
                            </div>
                            <p className="text-sm text-muted-foreground pl-11">{activity.description}</p>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
